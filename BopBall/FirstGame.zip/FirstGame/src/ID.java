
public enum ID
{
	Player(), Player2(), Ball(), Score(), Trail(), Goal();
}
